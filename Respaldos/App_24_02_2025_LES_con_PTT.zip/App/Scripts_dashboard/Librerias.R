#################
#   Librerias   # 
#################

###############
#  Librerías  # 
###############

suppressMessages(library(shiny))
suppressMessages(library(shinydashboard))
suppressMessages(library(readxl))
suppressMessages(library(dplyr))
suppressMessages(library(DT))
suppressMessages(library(plyr))
suppressMessages(library(readr))
suppressMessages(library(janitor))
suppressMessages(library(shiny))
suppressMessages(library(shinydashboard))
suppressMessages(library(shinydashboardPlus))
suppressMessages(library(highcharter))
suppressMessages(library(highcharter))
suppressMessages(library(viridisLite))
suppressMessages(library(stringi))
suppressMessages(library(data.table))
suppressMessages(library(tidyr))
suppressMessages(library(forecast))
suppressMessages(library(shinyWidgets))
suppressMessages(library(png))
suppressMessages(library(scales))
suppressMessages(library(gt))
suppressMessages(library(ggplot2))
suppressMessages(library(reactable))
suppressMessages(library(RcppRoll))
suppressMessages(library(sunburstR))
suppressMessages(library(htmltools))
suppressMessages(library(d3r))
suppressMessages(library(jfa))
suppressMessages(library(readxl))
suppressMessages(library(dplyr))
suppressMessages(library(openxlsx))
suppressMessages(library(fitdistrplus))
suppressMessages(library(MASS))
suppressMessages(library(ggplot2))
suppressMessages(library(stats))
suppressMessages(library(rmarkdown))
suppressMessages(library(officer))
suppressMessages(library(flextable))

# Versiones de las librerías   -----> Ver la versión de "attached base packages:"  y "other attached packages:"

sessionInfo()

